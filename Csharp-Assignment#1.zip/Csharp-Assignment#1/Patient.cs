﻿using System;

namespace Csharp_Assignment1
{
    class Patient
    {
        // Properties
        public string FirstName { get; }
        public string LastName { get; }
        public double Weight { get; }
        public double Height { get; }

        // Constructor
        public Patient(string firstName, string lastName, double weight, double height)
        {
            FirstName = firstName;
            LastName = lastName;
            Weight = weight;
            Height = height;
        }

        // Blood Pressure method
        public string BloodPressure(int systolic, int diastolic)
        {
            // Determine blood pressure category
            if (systolic < 120 && diastolic < 80)
            {
                return "NORMAL";
            }
            else if (systolic >= 120 && systolic <= 129 && diastolic < 80)
            {
                return "ELEVATED";
            }
            else if ((systolic >= 130 && systolic <= 139) || (diastolic >= 80 && diastolic <= 89))
            {
                return "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 1";
            }
            else if ((systolic >= 140 && systolic <= 180) || (diastolic >= 90 && diastolic <= 120))
            {
                return "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 2";
            }
            else if (systolic > 180 || diastolic > 120)
            {
                return "HYPERTENSIVE CRISIS (consult your doctor immediately)";
            }
            else
            {
                return "Blood pressure out of range. Consult your doctor.";
            }
        }

        // BMI Calculation method
        public double BMICalculation()
        {
            double heightInMeters = Height / 100; // Convert height from cm to meters
            return Math.Round(Weight / (heightInMeters * heightInMeters), 2);
        }

        // Patient Information method
        public string PatientInformation(int systolic, int diastolic)
        {
            double bmi = BMICalculation();
            string bmiStatus = GetBMIStatus(bmi);

            return $"Name: {FirstName} {LastName}\n" +
                   $"Weight: {Weight} kg\n" +
                   $"Height: {Height} cm\n" +
                   $"Blood Pressure: {BloodPressure(systolic, diastolic)}\n" +
                   $"BMI: {bmi}\n" +
                   $"BMI Status: {bmiStatus}";
        }

        // Get BMI Status
        private string GetBMIStatus(double bmi)
        {
            if (bmi >= 25.0)
            {
                return "Overweight";
            }
            else if (bmi >= 18.5 && bmi <= 24.9)
            {
                return "Normal (In the healthy range)";
            }
            else
            {
                return "Underweight";
            }
        }
    }
}