﻿using System;

namespace Csharp_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Prompt the user to enter their age
            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());

            // Input patient information
            Console.WriteLine("Enter patient information:");
            Console.Write("First Name: ");
            string firstName = Console.ReadLine();
            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();
            Console.Write("Weight (kg): ");
            double weight = Convert.ToDouble(Console.ReadLine());
            Console.Write("Height (cm): ");
            double height = Convert.ToDouble(Console.ReadLine());
            Console.Write("SYSTOLIC: ");
            int systolic = Convert.ToInt32(Console.ReadLine());
            Console.Write("DIASTOLIC: ");
            int diastolic = Convert.ToInt32(Console.ReadLine());

            // Instantiate Patient object
            Patient patient = new Patient(firstName, lastName, weight, height);

            // Output patient information
            Console.WriteLine("\nPatient Information:");
            Console.WriteLine(patient.PatientInformation(systolic, diastolic));

            // Keep the console window open
            Console.ReadLine();
        }
    }
}